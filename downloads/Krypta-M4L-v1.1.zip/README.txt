KRYPTA by Narti Live — Max for Live, v1.1 (free, MIT license)

Krypta by Narti Live.amxd      Instrument. Plays itself (STEP / TURING / METROPOLIS / DUB), just drones (DRONE), or from MIDI (MIDI in).
Krypta FX by Narti Live.amxd   Audio effect. The same voice processing the track's audio (Input), still sequenced.
                               Put it on drums and pick RESONATOR: the drums ring in the chord.

Nine algorithms: Pairs, Cluster, FM, Formant, Scan, Ring, Bands, Fold, Resonator.
Controls: Warp, Span, Morph, Scan (tone) - Fuse, Field, Env, Level (shape) - Shift, Space, Time, Form (space).
Every algorithm sits at about the same loudness. Everything stays in the chosen key.
Press play in Live: the sequencer follows Live's transport.

Needs Live 11 or 12 with Max for Live. Note: STEP / TURING / METROPOLIS patterns are new each time
the set loads (press NEW for another); the DUB pattern is saved with the set.

Original code, inspired by the idea of multi-algorithm stereo drone modules such as the Vhikk X.
Not affiliated with Forge TME, fors, Elektron or Ableton.
Web app: https://narti-live.github.io/dub-base-Plaits/krypta/

DRONE mode (v1.1): no sequencer. One chord in the chosen key is held and keeps sounding — Live's transport
is not needed. CHORD picks the shape, LENGTH = bars between changes, CHANGE = chance it moves to another
degree (0 % = static), NEW = next chord now. ENV in the swell range is the fade-in; pluck / long just hold.
