DUB STAB — Max for Live devices by Narti Live — v2.0
Textured, hypnotic dub techno tools: sequencers, effects and the Dub Stab synth.
Instagram @narti_live · youtube.com/@narti_live

Unofficial and free; use at your own risk. Needs Live 12 Suite (or Live + Max for Live).
INSTALL: drag a .amxd onto a track (or into your User Library to keep it). Sequencers follow
Live's transport: press PLAY.

NEW IN v2.0 ----------------------------------------------------------------------------

SEQUENCERS (MIDI effects: put them on a MIDI track before an instrument or a Drum Rack)

Hypno by Narti Live — polymeter sequencer
  Four lanes, each with its own length: they shift against each other and only line up
  again much later. Default: kick 16 steps / 4 hits, hat 12 / 7, clap 15 / 3, rim 13 / 5.
  Per lane: Note, Steps (1-32), Hits (spread evenly: Euclidean), Rot(ate), Chance,
  Vel(ocity), Ratch(et: chance of 2-3 fast repeats).
  Rate, Gate, Swing. MUTATE: each time lane 2-4 comes round it may flip one step and
  slowly drift back (lane 1 is the anchor). NEW: new rotations, mutations cleared.
  MIDI in passes through.

Roller by Narti Live — rolling techno bassline, always in key
  Style: ROLL (the three off-16ths of each beat), OFFBEAT, GALLOP, DUB (few long notes),
  BROKEN. Density, Move (how often it leaves the root: octave, 5th, 7th, 3rd),
  Accent, Slide (legato overlaps = glide on mono synths), Gate, Rate, Octave (2 = C1).
  Root + Scale (Natural minor, Dorian, Phrygian, Harmonic minor). A played MIDI note
  sets the root. Seed / NEW: same seed = same line.

Pulse by Narti Live — generative hypnotic drums (for a Drum Rack)
  Six lanes: Kick 36, Clap 39, Hat 42, Open 46, Rim 37, Perc 47 (notes can be changed).
  Each knob = density: turning it up adds hits in order of importance, the ones you
  hear stay. 4/4 KICK: four to the floor. Swing. VARY: from bar to bar a hit may come
  or go (the kick on the beat stays). Human: velocity. Fill: a busier last bar every
  4 / 8 / 16 bars. Seed / NEW. MIDI in passes through.

EFFECTS (audio effects)

Dub Echo by Narti Live — tape echo
  Time 1/16 .. 1/2D synced (changing it bends the repeats like tape). Feedback past
  100 % holds and grows (the saturation keeps it in check). Color (darker <-> thinner),
  Drive, Wow, Spread (0 straight, 100 ping-pong), Send, Mix.
  THROW: while on, the input goes into the echo at full level and the feedback rises.
  Map it to a pad. Send 0 + THROW = echo only what you throw.

Void by Narti Live — dark, huge, slowly moving space
  Size, Decay (0.6 .. 40 s), Dark, Motion, Pre(-delay), Low Cut (keeps kick and bass
  dry), Width, Mix. FREEZE: holds the space forever.

Dust by Narti Live — texture
  Crackle, Hiss, Wobble (wow and flutter), Wear (old record), Drive (tape), Grit (sample
  rate and bits), Follow (the noise follows the music: silence stays silent), Gain.
  Everything at 0 = clean.

Fog by Narti Live — a filter that moves on its own
  Cutoff, Reso (levels matched), Morph (low-pass -> band-pass -> high-pass), Drive.
  Drift: random movement of the cutoff, a new target every Drift rate (1/16 .. 4 bars),
  always on Live's beat. Spread: left and right drift apart. Pump: tempo-synced
  ducking (1/8, 1/4, 1/2). Mix.

A dub chain: Dub Stab Plaits -> Fog -> Dub Echo -> Void, Dust on the master.

FROM v1.0 ------------------------------------------------------------------------------

Dub Stab MIDI / Dub Stab Synth / Dub Stab Plaits — the DUB STAB PLAITS firmware's
sequencer and sound engines (see the website for the full list of controls).

Free, MIT license. Not affiliated with Ableton, Cycling '74 or Mutable Instruments.
