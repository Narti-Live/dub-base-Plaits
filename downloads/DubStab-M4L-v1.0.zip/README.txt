DUB STAB — Max for Live devices by Narti Live
Generative, controlled dub techno stabs. Made from the DUB STAB PLAITS firmware.
Instagram @narti_live · youtube.com/@narti_live

Unofficial and free; use at your own risk. Needs Live 12 Suite (or Live + Max for Live).

INSTALL
Drag a .amxd file onto a track (or into your User Library to keep it).
Press PLAY in Live: the sequencer follows Live's transport.

THE DEVICES
1. Dub Stab MIDI by Narti Live    (MIDI effect, on a MIDI track before any synth)
   The sequencer. Output: Chords, Acid line (one octave above), or Roots (one octave below).
2. Dub Stab Synth by Narti Live   (instrument)
   The firmware's sound engines, played from your own MIDI (or from Dub Stab MIDI).
   Notes that start within 8 ms are treated as one chord. ACID is mono: overlapping notes slide.
3. Dub Stab Plaits by Narti Live  (instrument)
   Both together, like the module: the sequencer plays the synth.

SEQUENCER
Root ........ key, C to B
Scale ....... Natural minor, Dorian, Phrygian, Harmonic minor
Minor chords only ... only the scale's minor (and diminished) chords
Voicing ..... DUB (root 5th 7th 3rd 5th), Triads, 7ths (any inversion), Mixed
Density ..... how many of the 16 steps play
Steps ....... pattern length
Rate ........ 1/2 to 1/32T, synced to Live
Octave ...... register (3 = as on the module)
CHORDS ...... on: chords. Off: mono notes (a line in the scale, from each chord root up to
              two octaves; the chord progression still decides the notes).
Seed / NEW .. the pattern is made from the seed: same seed + settings = same pattern.
              Saved with your Live set. Two devices on the same seed play the same pattern
              (e.g. one sends Chords, the other the Acid line).
MIDI in ..... a played note transposes the pattern within the scale (C3 = no change)

SYNTH
Model: DUB SAW, VA, WAVESHAPE, FM, PHASE DIST, CHIPTUNE, STRINGS, ACID
Harmonics / Timbre / Morph ... as on the module
Envelope .... the FREQUENCY knob: short dark pluck -> dub stab -> long swell
Resonance ... filter resonance (never self-oscillates)
Drift ....... the slow random LFO (15 % = as on the module)
ACID ........ Envelope = env mod, Harmonics = cutoff, Morph = resonance, Timbre = accent
Add Live's Echo and Hybrid Reverb after it for the full dub sound.
