MONSOON — Narti Live firmware v1.8 (Parasites v2.01 for Monsoon + new modes)
unofficial, use at your own risk

MODES (open mode select: press the LED button + LOAD/SAVE together, or hold the
LED button 2.5 s; then LOAD/SAVE = next mode, LED button = previous mode)
  1 Granular          LED 1           (unchanged)
  2 Pitch / stretch   LED 2           (unchanged)
  3 Looping delay     LED 3           (unchanged)
  4 PHASER            LED 4           stereo phaser (new)
  5 MI reverb         all but LED 1   (unchanged)
  6 Resonator         all but LED 2   (unchanged)
  7 CAVERN            all but LED 3   Vhikk X-inspired stereo delay / space (new)
  8 VHIKK             all but LED 4   Vhikk X-inspired voice + processor (new)
To leave the mode-select screen: hold the LED button ~1 s, then ~1 s again.

------------------------------------------------------------------------------
8  VHIKK (Vhikk X-inspired drone voice + processor)
An original stereo drone voice highly inspired by the Forge TME Vhikk X: nine
algorithms, each a generator -> FIELD filter -> VCA, then the processor (the
CAVERN engine as a metallic DUNGEON or a diffuse REFLEKTA delay). Anything at
the audio inputs goes straight to the effects (not through the FIELD filter
or the VCA); its dry part follows MIX like the generator. Stereo out.

ONE PAGE - every function has its own control:
  POSITION slider ... TIME   delay length, 20 ms - 0.8 s (glides)
  DENSITY slider .... CELL   frequency shift in the loop, none at noon
  SIZE slider ....... MORPH  timbral scan (wave / wavetable frame / cluster)
  TEXTURE slider .... FORM   repeats > metallic > diffuse (reverb-like)
  PITCH knob ........ BASIS  octave switch: -2 / -1 / 0 / +1 / +2 octaves
                             (5 positions, C2 at noon)
  V/OCT ............. note, 1 V/oct on top of the octave
  DRY/WET knob ...... MIX    generator <-> processor
  STEREO knob ....... WARP   cross modulation (two kinds, left / right of noon)
  FEEDBACK knob ..... FEED   neutral at noon. Left: the output hears the
                             frequency shifter alone; right: shifter blended
                             with the raw echoes (moving notches)
  REVERB knob ....... FIELD  low-pass (left) / open (noon) / high-pass (right),
                             one smooth sweep through noon
The Monsoon has 9 controls and the Vhikk X has 12, so three functions live on
the LED button, the way the Vhikk X shares its encoders:
  hold LED button + STEREO .. SPAN   oscillator spread / tuning (right of
                                     noon adds stereo width)
  hold LED button + REVERB .. FUSE   colour, depends on the algorithm
  hold LED button + SIZE .... SCAN   second timbral scan (table set)
  (soft takeover: when you press or release the LED button, a control that
   was left elsewhere does not jump - it catches up smoothly as you turn it
   and meets the knob; LED 4 is red while the LED button is held)

BUTTONS AND JACKS
  LED button tap ...... next algorithm 1..9. LED 1-3 show the two switches of
                        the original: green = first switch (up / centre /
                        down), red = second switch, amber = both on one LED.
                        Green glows with the VCA.
  LOAD/SAVE tap ....... SCAN to the next table set
  FREEZE tap .......... SEED: new random pitch / wave offsets and echo spacing
  FREEZE hold 1 s ..... freeze the processor loop (LED 4 blue); again to free
  FREEZE jack ......... gate = freeze the processor loop
  TRIG jack ........... VCA. Nothing patched: drone. Patch a clock or gates:
                        each trigger plays a stab whose decay follows the
                        trigger rate; 3 s without triggers = the drone swells
                        back in (about 1 s).
  V/OCT as trigger .... one cable from a sequencer is enough (e.g. the Plaits
                        AUX pitch out): every NEW note at V/OCT fires the VCA,
                        2 ms after the jump so the pitch has settled. The same
                        note twice in a row does not retrigger (use TRIG for
                        that). Slow LFOs / vibrato (under 0.4 semitone per
                        step) never trigger.
                        As soon as TRIG gets pulses, TRIG alone fires the VCA
                        (V/OCT then only sets the pitch); 2 s after the last
                        TRIG pulse, V/OCT notes trigger again.
  Mode select ......... hold the LED button 2.5 s without moving a control
                        (or LED + LOAD/SAVE together)

ALGORITHMS (first switch / second switch) - each with its own character
  1 up/up         ANALOGUE PAIR + DUNGEON: carrier + modulator with a soft sub
                  an octave down; clear tape-like repeats.
                  WARP L expo FM, R ring mod; SPAN modulator tuning; MORPH
                  carrier pulse>saw>sine; SCAN modulator wave; FUSE L chorus,
                  R resonance + band-pass
  2 up/centre     WAVESHAPING PAIR + REFLEKTA: a stereo shaped pair.
                  WARP L index + mod feedback, R index + carrier feedback; SPAN
                  carrier ratio; SCAN shaper set; FUSE L audio-rate delay mod,
                  R saturation
  3 up/down       SINE CLUSTER + DUNGEON: pure sines that shimmer slowly.
                  WARP L phase feedback, R cross FM; MORPH cluster; SCAN
                  ring-mod mix; FUSE L chorus, R noise modulation
  4 centre/up     STACK WAVETABLE + DUNGEON: four detuned oscillators, a
                  built-in unison chorus. WARP L bit reduction, R cross FM;
                  MORPH frame; SCAN table set; SPAN wider unison; FUSE L
                  band-pass + sine, R chorus + resonance
  5 centre/centre FM WAVETABLE + DUNGEON (short, bright combs): two carrier /
                  modulator pairs, bells, keys, glass. SPAN = the ratio (0.5,
                  1, 1.5, 2 ... 7), WARP L the FM index, R cross FM; MORPH
                  carrier frame; SCAN carrier set; FUSE L chorus + sub
  6 centre/down   FORMANT WAVETABLE + REFLEKTA: window-synced grains, vocal
                  and resonant. MORPH = the vowel / formant, WARP L formant
                  wobble, R cross FM; SCAN table set; FUSE L oscillator all-
                  pass, R wavefold
  7 down/up       DIATONIC PAD + REFLEKTA (long, dark): minor-scale chord
                  tones on soft tables that breathe slowly
  8 down/centre   METAL CLUSTER + DUNGEON (short metallic combs): inharmonic,
                  bell-like partials that ring into each other
  9 down/down     SWARM + REFLEKTA (very long wash): octave stacks of drifting,
                  shimmering voices
                  (7-9: WARP L phase mod, R cross FM; SPAN spread; MORPH
                  cluster scan; SCAN table set; FUSE L stereo chorus,
                  R saturation)

------------------------------------------------------------------------------
7  CAVERN (Vhikk X-inspired space)
  POSITION TIME · SIZE FIELD · DENSITY CELL (shift) · TEXTURE FORM
  PITCH + V/OCT FUSE (left chorus, right saturation) · FEEDBACK · STEREO spread
  DRY/WET · REVERB (Clouds reverb) · FREEZE holds the loop · TRIG = SEED

4  PHASER
  POSITION rate · SIZE depth · PITCH + V/OCT centre · DENSITY LFO shape
  TEXTURE stages 2-12 · FEEDBACK resonance · STEREO L/R offset · DRY/WET mix
  REVERB Clouds reverb · FREEZE holds the sweep · TRIG restarts the LFO

INSTALL
  Hold FREEZE and power on, play Monsoon-NartiLive-v1.8.wav (about 5.5 minutes) into IN L (no MP3,
  no notification sounds). The module restarts when it is done.
GO BACK
  Monsoon-ORIGINAL-Parasites-v2.01-restore.wav = the original Monsoon firmware
  (Tom Burns, github.com/boourns/eurorack). Install it the same way.

CHANGES
  v1.8  Feel and transitions, the way a finished module should behave:
        - every knob and slider responds in a few milliseconds when you move
          it (was up to 0.2 s) and stays still when you do not (dynamic
          smoothing: ADC noise filtered as before), CV follows faster too;
          V/OCT is steadier (pitch jitter 1.1 -> 0.4 cents), notes still jump
        - no zipper noise: every VHIKK and CAVERN control moves per sample
          (wavetable and cluster crossfades, filters, MIX, FEED, FUSE ...)
        - MORPH sweeps the clusters (3, 7, 8, 9) without clicks
        - FIELD passes noon without a click or a dropout (two filters that
          fade in and out instead of switching)
        - changing algorithm: a 6 ms fade, the new one fades in, the
          processor glides to its new space; no level jump
        - the drone swells back in instead of jumping in after stabs, and a
          stab on a drone takes over without a gap
        - V/OCT notes and the BASIS octave switch: clean pitch changes
        - FREEZE fades the input out of the loop instead of cutting it
        - soft takeover for SPAN / FUSE / SCAN (LED button)
        - changing mode or quality fades out and in (no pop), the output
          fades in at power-on
        - settings are saved 2 s after the last change (no flash writes
          while you tap through algorithms)
        - a filter that could blow up when FIELD jumped across its whole
          range is fixed; NaN / runaway watchdog resets the voice cleanly
  v1.7  Every VHIKK algorithm has its own character (sub oscillator, shimmer,
        unison stack, FM, formant, breathing pad, metal, swarm) and its own
        space (delay time, structure and tone).
  v1.6  VHIKK sounds cleaner and keeps its level:
        - band-limited wavetables with 4x more harmonics (96), switching
          smoothly to simpler versions as the pitch goes up: no aliasing fizz
        - the waveshaper runs at twice the rate, cross FM gets gentler at
          high pitches, two soft poles at ~13 kHz smooth the very top
        - slow analogue-like drift of every oscillator (a few cents)
        - automatic level: every algorithm and knob position at a similar
          loudness (measured within 2 dB between algorithms; FIELD at its
          extremes within about 5 dB), the processor follows what goes in
        - subtle built-in saturation after the VCA, a clean peak limiter at
          the end (no soft clipping, nothing near full scale)
        - smoother delay taps in the processor (also in CAVERN)
        - FIELD has a more musical range (12 kHz - 110 Hz, 25 Hz - 2.8 kHz)
  v1.5  VHIKK: PITCH knob = octave switch, V/OCT notes fire the VCA (TRIG
        wins when patched), audio inputs only go through the effects.
  v1.4  Mode 8 is now VHIKK (Vhikk X-inspired voice + processor, one page).
        The LOQUAX VOICE mode of v1.3 is gone.
  v1.2  CAVERN: POSITION and DENSITY glide (no clicks).
  v1.1  CAVERN mode.   v1.0  Stereo phaser instead of spectral.

Built from the Monsoon Parasites source (Clouds by Emilie Gillet, Parasites by
Matthias Puech, Monsoon port by Tom Burns), MIT license. CAVERN and VHIKK are
original code inspired by the Forge TME Vhikk X; not affiliated with Forge TME.
